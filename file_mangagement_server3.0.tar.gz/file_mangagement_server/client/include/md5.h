#ifndef __MD5_H__
#define __MD5_H__

#include "head.h"

int get_md5(int, char *);

#endif
