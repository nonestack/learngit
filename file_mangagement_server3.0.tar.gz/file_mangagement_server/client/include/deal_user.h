#ifndef __DEAL_USER_H__
#define __DEAL_USER_H__

#include "head.h"

int	send_log(int);

#endif
