#ifndef __DEAL_DESCRIPTION_H___
#define __DEAL_DESCRIPTION_H___
#include "head.h"

int extract_conf(char *, char *, char *, int *, int *);

int tcp_init(int *, char *, char *);
#endif
